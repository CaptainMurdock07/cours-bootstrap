package beans;

public class Employe {
	private int noEmploye;
	private String nom;
	private String prenom;
	private String fonction;
	private double salaire;
	
	public int getNoEmploye() {
		return noEmploye;
	}
	public void setNoEmploye(int noEmploye) {
		this.noEmploye = noEmploye;
	}
	public String getNom() {
		return nom;
	}
	public void setNom(String nom) {
		this.nom = nom;
	}
	public String getPrenom() {
		return prenom;
	}
	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}
	public String getFonction() {
		return fonction;
	}
	public void setFonction(String fonction) {
		this.fonction = fonction;
	}
	public double getSalaire() {
		return salaire;
	}
	public void setSalaire(double salaire) {
		this.salaire = salaire;
	}
	
	
	
}
